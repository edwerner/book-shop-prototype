package react.app.server;

public interface Application {}
