var Mongoose = require('mongoose');

var ProductSchema = new Mongoose.Schema({
	name: String,
	price: String,
	image: String,
	description: String
});

module.exports = Mongoose.model('Product', ProductSchema);