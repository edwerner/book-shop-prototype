var Mongoose = require('mongoose');
var bCrypt = require('bcrypt-nodejs');

var UserSchema = new Mongoose.Schema({
	username: String,
	password: String,
	first_name: String,
	last_name: String,
	email: String,
	new_user: Boolean
});

UserSchema.methods.verifyPassword = function(password, callback) {
  bCrypt.compare(password, this.password, function(err, isMatch) {
    if (err) return callback(err);
    callback(null, isMatch);
  });
};

module.exports = Mongoose.model('User', UserSchema);