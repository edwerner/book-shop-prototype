var Mongoose = require('mongoose');
var User = require('./user');
var uriString = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017';
var db = Mongoose.connection;
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var RegisterStrategy = require('passport-local-register');
var bCrypt = require('bcrypt-nodejs');
var $ = require('jquery');
var promisify = require('promisify-node');

var initialize = function() {
  Mongoose.connect(uriString, function(err, res) {
    if (err) {
      console.log("Error connecting to: " + uriString + '. ' + err);
    } else {
      console.log('Succeeded connected to: ' + uriString);
    }
  });
  db.on('error', console.error.bind(console, 'connection error:'));
}

var isValidPassword = function(user, password){
  return bCrypt.compareSync(password, user.password);
}

// Generates hash using bCrypt
var createHash = function(password){
 return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
}

passport.use('login', new LocalStrategy({
    passReqToCallback : true
  },
  function(req, username, password, done) { 
    // check in mongo if a user with username exists or not
    User.findOne({'username':username}, 
      function(err, user) {
        // In case of any error, return using the done method
        if (err)
          return done(err);
        // Username does not exist, log error & redirect back
        if (!user){
          console.log('User Not Found with username '+ username);
          return done(null, false);                 
        }
        // User exists but wrong password, log the error 
        if (!isValidPassword(user, password)){
          console.log('Invalid Password');
          user.new_user = true;
          return done(null, user);
        }
        // User and password both match, return user from 
        // done method which will be treated like success
        return done(null, user);
      }
    );
}));

passport.serializeUser(function(user, done) {
  done(null, user._id);
});
 
passport.deserializeUser(function(id, done) {
  User.findById(id, function(err, user) {
    done(err, user);
  });
});

passport.use('register',
  new LocalStrategy({
    usernameField: 'username',
    passwordField: 'password',
    passReqToCallback: true
  },
  function(req, username, password, done) {
      // var token = req.body.token || req.query.token || req.headers['x-access-token'];
      // console.log("TOKEN");
      // console.log(token);
    findOrCreateUser = function() {

      // User.find({username: username}).remove().exec();
      // find a user in Mongo with provided username
      User.findOne({'username':username}, function(err, user) {
        // return console.log(user);
        // In case of any error return
        if (err) {
          // console.log('Error in SignUp: '+ err);
          return done(err);
        }

        if (user) {
          user.verifyPassword(password, function(err, isMatch) {
            if (err) {
              return done(err);
            }
            // Password did not match
            if (!isMatch) {
              return done(null, false);
            }
            else {
              user.new_user = false;
              var promise = promisify(user.save());
              promise.then(function() {
                return done(null, user);
              }).catch(function(error) {
                throw error;
              });
            }
          });
        }
        else {
          var newUser = new User();
          newUser.username = username;
          newUser.password = createHash(password);
          newUser.first_name = req.param('first_name');
          newUser.last_name = req.param('last_name');
          newUser.email = req.param('email');
          newUser.new_user = true;

          var promise = promisify(newUser.save());

          promise.then(function() {
            return done(null, newUser);
          }).catch(function(error) {
            throw error;
          });
        }
      });
    }
     
    // Delay the execution of findOrCreateUser and execute 
    // the method in the next tick of the event loop
    process.nextTick(findOrCreateUser);
  }));

module.exports.initialize = initialize;