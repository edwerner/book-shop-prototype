var Mongoose = require('mongoose');

var CartSchema = new Mongoose.Schema({
	cart_items: Array, // {product_id: id, quantity: quantity}
	user_id: String
});

var currentUserId = undefined;

module.exports = Mongoose.model('Cart', CartSchema);