var Product = require('./product');
var Products = require('../json/products');
var productMap = {};

var findAllProducts = function() {
 	Product.find({}, function(err, product) {
    if (err) return err;
    if (product) {
      productMap.name = product.name;
      productMap.price = product.price;
      productMap.image = product.image;
      productMap.description = product.description;
    }
  });
}

var getProductMap = function() {
	return productMap;
}

var createProducts = function() {
	for (var key in Products) {
    if (Products.hasOwnProperty(key)) {
      var attributes = Products[key]; 
      var product = new Product();
      product.name = key;
      product.price = attributes.price;
      product.image = attributes.image;
      product.description = 'Product description';
      product.save();
    }
  }
}

var removeProducts = function() {
  Product.remove({}, function() {
    return console.log('products removed');
  });
}

module.exports.findAllProducts = findAllProducts;
module.exports.getProductMap = getProductMap;
module.exports.createProducts = createProducts;
module.exports.removeProducts = removeProducts;