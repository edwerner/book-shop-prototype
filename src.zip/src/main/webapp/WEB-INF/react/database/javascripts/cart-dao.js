var Cart = require('./cart');
var promisify = require('promisify-node');
var currentUserId;
var cartInstance = undefined;
var currentCartItem = undefined;

var findCartItemById = function(cartItem) {
  if (cartItem.product_id == getCurrentCartItem().product_id) {
    return cartItem;
  }
}

var cartItemExists = function(cartItem, cartItems) {
  setCurrentCartItem(cartItem);
  return cartItems.find(findCartItemById);
}

var setCurrentCartItem = function(item) {
  currentCartItem = item;
}
var getCurrentCartItem = function() {
  return currentCartItem;
}

var setCurrentCart = function(cart) {
  cartInstance = cart;
}

var getCurrentCart = function() {
  return cartInstance;
}

var setCurrentUserId = function(userId) {
  currentUserId = userId;
}

var getCurrentUserId = function() {
  return currentUserId;
}

var createCart = function() {
  var cart = new Cart();
  cart.user_id = getCurrentUserId();
  cart.cartItems = [];
  return cart;
}

var updateOrCreateCartItem = function(cartItem) {
  var cart = getCurrentCart();
  if (cart) {
    console.log(cart);
    var item = cartItemExists(cartItem, cart.cart_items);
    if (item) {
      item.quantity = cartItem.quantity;
    } else {
      cart.cart_items.push(cartItem);
    }
  }
}

module.exports.setCurrentUserId = setCurrentUserId;
module.exports.getCurrentUserId = getCurrentUserId;
module.exports.setCurrentCart = setCurrentCart;
module.exports.getCurrentCart = getCurrentCart;
module.exports.createCart = createCart;
module.exports.updateOrCreateCartItem = updateOrCreateCartItem;