# OpenShoppingCart
Single-page application built on React

mongod --config C:/Users/Edward/Desktop/reactjs/react-webpack/database/mongod.conf --install
mongod --dbpath=C:/Users/Edward/Desktop/reactjs/react-webpack/database/
mongo
